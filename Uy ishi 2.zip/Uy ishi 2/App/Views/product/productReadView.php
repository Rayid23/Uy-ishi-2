<h1 align="center">Подробности</h1>

<div class="col-12">
    <a class="btn btn-primary" href="/Product">Назад</a>
</div>

<div align="center" class="mt-3">



    <div class="card text-center" style="width: 38rem;">
        <img src="<?= "App/Views/product/" . $models->image ?>" class="card-img-top" alt="..." style="border:2px solid black">
        <div class="card-body" style="border:2px solid black">
            <h1 class="card-title"><?= $models->name ?></h1>
        </div>
    </div>
</div>