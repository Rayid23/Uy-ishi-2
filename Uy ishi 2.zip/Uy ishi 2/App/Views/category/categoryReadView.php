<h1 align="center">Подробности</h1>

<div class="col-12">
    <a class="btn btn-primary" href="/Category">Назад</a>
</div>

<h1 align="center" class="mt-2">Категория: <?=$models->name?></h1>