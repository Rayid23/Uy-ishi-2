<?php 

namespace App\Models;

class Product extends Model
{
    public static $table = "product";

}
