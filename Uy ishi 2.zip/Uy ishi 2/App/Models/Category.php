<?php

namespace App\Models;

class Category extends Model
{
    public static $table = "category";
}

?>