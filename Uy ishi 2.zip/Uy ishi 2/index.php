<?php

include("autoload.php");
include("web.php");
include("App/Helpers/helpers.php");

use App\App;

$app = new App();

$app->run();

?>